Hello!

All STATA code is located in the Final Stata Files folder. This code is run in a specific order: RawDataConversion, DispensaryDataCleaning,
VariableCalculation, RegressionCalculations, HKCSWork, and finally SummaryStatistics. I will include log files
so you can see the output. 

The STATA code converts raw excel files into STATA files, which are then cleaned and combined into a single data set. This data set is then used to calculate 
treatment and control variables. Finally, regressions are run and output files are created, including graphs and tables. The tables were manually edited after
creation in STATA, the output is raw .csv files. 